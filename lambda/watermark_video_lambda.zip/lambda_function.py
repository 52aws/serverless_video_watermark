import os
import urllib.parse as urlparse
import datetime
import warnings
import subprocess
import base64
import boto3
import time

# 设置环境变量
zlib_path = "/opt/lib"
ffmpeg_path = '/opt/ffmpeg'
os.environ['LD_LIBRARY_PATH'] = (zlib_path + os.pathsep + os.environ.get('LD_LIBRARY_PATH', '')).strip(os.pathsep)
os.environ['PATH'] = ffmpeg_path + os.pathsep + os.environ['PATH']

from PIL import Image, ImageDraw, ImageFont
import av

# aws client
s3_2 = boto3.client('s3')

# 水印字体
font_type = "/opt/simhei.ttf"
font_size = 100

# 小水印边缘宽度
x_length, y_length = 10, 10

# 忽略DeprecationWarning警告
warnings.filterwarnings("ignore", category=DeprecationWarning)

density_map = {
    "1": {"row":2, "col": 2},
    "2": {"row":3, "col": 3},
}

# 记录方法执行时间
def timeit(desc=""):
    def decorator(func):
        def wrapper(*args, **kwargs):
            start = time.time()
            result = func(*args, **kwargs)
            end = time.time()
            print(f"{desc}执行时间: {end - start:.5f}(s)")
            return result

        return wrapper

    return decorator


# 根据请求url获取水印参数
def get_water_params(event):
    # get请求url
    url_params = urlparse.parse_qs(urlparse.urlparse(event['userRequest']['url']).query)

    # 水印内容 默认加当前日期 yyyymmddHHMM
    content = datetime.datetime.now().strftime('%Y%m%d%H%M')
    new_content = content
    if url_params.get('X-Amz-WatermarkContent'):
        content = url_params.get('X-Amz-WatermarkContent')[0]
        # 解码Base64字符串
        try:
            new_content = base64.b64decode(content).decode('utf-8')
        except Exception as e:
            print(f"base64解码失败:{e}")
            new_content = content
    content = [i.strip() for i in new_content.split(",") if i.strip()]

    # 水印颜色
    color = url_params.get('X-Amz-WatermarkColor')[0] if url_params.get('X-Amz-WatermarkColor') else 'rgba(255,0,0,1)'
    color = color.replace('rgba', '').replace('(', '').replace(')', '').split(',')
    color = [int(i) for i in color[0:3] if i]

    # 水印不透明度
    opacity = float(url_params.get('X-Amz-WatermarkPreviewOpacity')[0]) if url_params.get(
        'X-Amz-WatermarkPreviewOpacity') else 1
    opacity = int(opacity * 255)

    # 水印旋转角度
    rotate = url_params.get('X-Amz-WatermarkRotate')[0] if url_params.get('X-Amz-WatermarkRotate') else 8
    rotate = int(rotate)

    density = url_params.get('X-Amz-WatermarkDensity')[0] if url_params.get('X-Amz-WatermarkDensity') else "1"


    return {
        "content": content,
        "color": color,
        "opacity": opacity,
        "rotate": rotate,
        "density": density,
    }


# 视频画面宽度和高度
@timeit(desc="获取视频宽度和高度")
def get_video_resolution(filename):
    # 打开 URL 上的视频
    container = av.open(filename)
    # 获取视频流
    video_stream = next(s for s in container.streams if s.type == 'video')
    # 获取视频帧的宽度和高度
    width = video_stream.width
    height = video_stream.height
    return width, height


# 最小水印图像
def get_watermark_image_min(watermark):
    content = watermark['content']
    color = watermark['color']
    opacity = watermark['opacity']
    rotate = watermark['rotate']

    # 字体字号设置
    font = ImageFont.truetype(font_type, font_size)

    # 每行文字信息
    x_size = [font.getsize(line)[0] for line in content]
    y_size = [font.getsize(line)[1] for line in content]

    # 水印位置
    text_position = (x_length, y_length)

    # 水印图片尺寸
    image_min_width = int(max(x_size)) + x_length * 2
    space = int(min(y_size) * 0.2)
    image_min_height = int(sum(y_size) + (len(y_size) - 1) * space) + y_length * 2
    middle_x = int(max(x_size) / 2)

    # 创建一个小水印图片
    image_min = Image.new('RGBA', (image_min_width, image_min_height), (0, 0, 0, 0))
    draw = ImageDraw.Draw(image_min)

    # 添加水印
    for line in content:
        # 水印位置
        x_location = text_position[0] + (middle_x - (font.getsize(line)[0] / 2))
        y_location = text_position[1]
        # 添加水印
        draw.text((x_location, y_location), line, font=font, fill=(color[0], color[1], color[2], opacity))
        # 水印新的纵坐标
        line_height = font.getsize(line)[1]
        text_position = (text_position[0], text_position[1] + line_height + space)

    # 水印图像旋转
    image_min = image_min.rotate(rotate, expand=True, resample=Image.BICUBIC)
    # image_min.save("./image_small.png", "PNG")

    return image_min


# 生成一张和视频相同尺寸的水印图像
def get_watermark_image(image_min, input_file, image_file):
    # 小水印图片尺寸
    image_min_width, image_min_height = image_min.size
    # print(f"原始水印图片大小:{image_min_width} * {image_min_height}")

    # 视频画面尺寸
    watermark_width, watermark_height = get_video_resolution(input_file)
    print(f'视频大小: {watermark_width} * {watermark_height}')

    # 缩放小水印图片
    resize_num = 3 if ((watermark_width/watermark_height) >= 1.2) else 2
    if (watermark_height / watermark_width) > 3:
        resize_num = 1.6
    image_min_width_new = int(watermark_width / resize_num)
    image_min_height = int(image_min_width_new * image_min_height / image_min_width)
    image_min_width = image_min_width_new
    image_min = image_min.resize((image_min_width, image_min_height), resample=Image.BICUBIC)
    # print(f"缩放后水印图片大小:{image_min_width} * {image_min_height}")

    # 创建一个水印图片
    watermark_image = Image.new('RGBA', (watermark_width, watermark_height), (0, 0, 0, 0))

    # 计算水印图片在原始图片上重复叠加的次数
    repeat_num = 2 if ((2 * image_min_height) > watermark_height) else 4

    middle_x_1, middle_y_1 = int(watermark_width/4), int(watermark_height/4)
    middle_x_4, middle_y_4 = int(3 * watermark_width / 4), int(3 * watermark_height / 4)
    watermark_image.paste(image_min, (middle_x_1 - int(image_min_width / 2), middle_y_1 - int(image_min_height / 2)), image_min)
    watermark_image.paste(image_min, (middle_x_4 - int(image_min_width / 2), middle_y_4 - int(image_min_height / 2)), image_min)
    if repeat_num == 4:
        middle_x_2, middle_y_2 = int(3 * watermark_width / 4), int(watermark_height / 4)
        middle_x_3, middle_y_3 = int(watermark_width / 4), int(3 * watermark_height / 4)
        watermark_image.paste(image_min, (middle_x_2 - int(image_min_width / 2), middle_y_2 - int(image_min_height / 2)), image_min)
        watermark_image.paste(image_min, (middle_x_3 - int(image_min_width / 2), middle_y_3 - int(image_min_height / 2)), image_min)
    watermark_image.save(image_file, "PNG")


def get_watermark_image_v2(watermark_image, input_file, image_file, row, col):
    # 原始水印图片尺寸(大尺寸)
    origin_watermark_image_width, origin_watermark_image_height = watermark_image.size
    print(f"原始水印图片大小:{origin_watermark_image_width} * {origin_watermark_image_height}")

    # 视频画面尺寸
    video_width, video_height = get_video_resolution(input_file)
    print(f'视频大小: {video_width} * {video_height}')

    # 创建一个水印图片
    video_image = Image.new('RGBA', (video_width, video_height), (0, 0, 0, 0))
    if video_width >= video_height:
        video_image = generate_width_watermark_image(video_width,video_height,
                                                       origin_watermark_image_width, origin_watermark_image_height,
                                                       watermark_image, row, col, video_image)
    else:
        video_image = generate_height_watermark_image(video_width, video_height,
                                                      origin_watermark_image_width, origin_watermark_image_height,
                                                      watermark_image, row, col, video_image)
    video_image.save(image_file, 'png')


# 横板视频
def generate_width_watermark_image(video_width, video_height, origin_width, origin_height, watermark_image, row, col, video_image):
    # 缩放小水印图片
    watermark_image_width = int(video_width / (col + 1))
    watermark_image_height = int(watermark_image_width * origin_height / origin_width)
    watermark_image = watermark_image.resize((watermark_image_width, watermark_image_height), resample=Image.BICUBIC)
    print(f"缩放后水印图片大小:{watermark_image_width} * {watermark_image_height}")

    distance_x = int(watermark_image_width / (col - 1))
    distance_y = int(video_height / (2 * row + 1))

    for rowNum in range(row):
        for colNum in range(col):
            id_x = int(colNum * watermark_image_width + colNum * distance_x)
            id_y = int(0.5 * watermark_image_height + (2 * rowNum + 1) * distance_y - watermark_image_height / 2)
            video_image.paste(watermark_image, (id_x, id_y), watermark_image)
    return video_image


# 竖版视频
def generate_height_watermark_image(video_width, video_height, origin_width, origin_height, watermark_image, row, col, video_image):
    # 缩放小水印图片
    watermark_image_height = int(video_height / (row + 4))
    watermark_image_width = int(watermark_image_height * origin_width / origin_height)
    watermark_image = watermark_image.resize((watermark_image_width, watermark_image_height), resample=Image.BICUBIC)
    print(f"缩放后水印图片大小:{watermark_image_width} * {watermark_image_height}")

    distance_y = int(2 * watermark_image_height / (row - 1))
    distance_x = int(video_width / (2 * col + 1))

    for rowNum in range(row):
        for colNum in range(col):
            id_y = int(watermark_image_height + rowNum * watermark_image_height + rowNum * distance_y)
            id_x = int(0.1 * watermark_image_width + (2 * colNum + 1) * distance_x - watermark_image_width / 2)
            video_image.paste(watermark_image, (id_x, id_y), watermark_image)
    return video_image

# 视频加水印
@timeit(desc="视频加水印")
def video_trans(input_file, image_file, output_file):
    # 生成添加水印的命令
    command = f'{ffmpeg_path} -y -i "{input_file}" -i {image_file} -filter_complex "[0:v][1:v]overlay=0:0" -preset superfast -f mpegts -copyts -c:v libx264 -c:a copy {output_file}'
    print(f"command: {command}")

    # 使用 FFmpeg 添加水印
    process = subprocess.run(command, shell=True, stdout=subprocess.PIPE, stderr=subprocess.PIPE)
    # print(f"stderr: {process.stderr.decode()}")
    # print(f"stdout: {process.stdout.decode()}")


def params_check(event):
    url_params = urlparse.parse_qs(urlparse.urlparse(event['userRequest']['url']).query)
    expires = url_params.get('X-Amz-Expires')[0] if url_params.get('X-Amz-Expires') else 0
    ts = url_params.get('X-Amz-Date')[0] if url_params.get('X-Amz-Date') else 0

    if expires == 0 and ts == 0:
        print("缺少参数: X-Amz-Expires, X-Amz-Date")
        return

    # 将UTC时间字符串转换为datetime对象
    req_time = datetime.datetime.strptime(ts, '%Y%m%dT%H%M%SZ')
    expire_time = req_time + datetime.timedelta(seconds=int(expires))

    # 获取当前utc时间
    now = datetime.datetime.now()
    utc_now = now.astimezone(datetime.timezone.utc)
    utc_now = utc_now.replace(tzinfo=None)
    if utc_now > expire_time:
        print(f"请求时间:{req_time}, 过期时间:{expire_time}, 系统时间:{utc_now}")
        raise Exception("签名超时")


# 入口
def lambda_handler(event, context):
    tt1 = time.time()
    # 超时检查
    params_check(event)

    # 水印参数
    watermark = get_water_params(event)
    print(f"水印信息:{watermark}")

    # 加水印的视频url
    # 原始ts文件url
    input_file = event['getObjectContext']['inputS3Url']

    # 水印文件不存在
    # 小水印图像
    image_min = get_watermark_image_min(watermark)

    # 水印图像
    image_file = f"/tmp/video.png"
    if watermark['density'] == "1" or not density_map.get(watermark['density']):
        get_watermark_image(image_min, input_file, image_file)
    else:
        row = density_map.get(watermark['density'],{}).get('row')
        col = density_map.get(watermark['density'], {}).get('col')
        get_watermark_image_v2(image_min, input_file, image_file, row, col)

    # 设置输出文件的位置和格式
    output_file = f'/tmp/video.ts'
    # 输出文件的Route和Token
    object_get_context = event["getObjectContext"]

    # 视频加水印
    video_trans(input_file, image_file, output_file)

    # 返回视频流
    with open(output_file, 'rb') as f:
        video_stream = f.read()


    tt2 = time.time()
    print(f"整体耗时:{round(tt2 - tt1, 2)}(s)")

    # 结果返回
    s3_2.write_get_object_response(
        Body=video_stream,
        RequestRoute=object_get_context["outputRoute"],
        RequestToken=object_get_context["outputToken"],
        ContentType="video/MP2T")
    return {'status_code': 200}