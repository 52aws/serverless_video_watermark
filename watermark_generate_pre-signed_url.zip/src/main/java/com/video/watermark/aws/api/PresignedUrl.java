package com.video.watermark.aws.api;


import com.video.watermark.aws.auth.AWS4SignerBase;
import com.video.watermark.aws.auth.AWS4SignerForQueryParameterAuth;
import com.video.watermark.config.S3Config;
import com.video.watermark.module.GeneratePresignedUrlReq;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.net.MalformedURLException;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;

/**
 * Sample code showing how to use Presigned Urls with Signature V4 authorization
 */
@Slf4j
public class PresignedUrl {
     
    /**
     * Construct a basic presigned url to the object '/ExampleObject.txt' in the
     * given bucket and region using path-style object addressing. The signature
     * V4 authorization data is embedded in the url as query parameters.
     */
    public static void getPresignedUrlToS3Object(String bucketName, String regionName, String awsAccessKey, String awsSecretKey) {
        System.out.println("******************************************************");
        System.out.println("*    Executing sample 'GetPresignedUrlToS3Object'    *");
        System.out.println("******************************************************");
        
        URL endpointUrl;
        try {
            if (regionName.equals("us-east-1")) {
                endpointUrl = new URL("https://s3.amazonaws.com/" + bucketName + "/ExampleObject.txt");
            } else {
                endpointUrl = new URL("https://s3-" + regionName + ".amazonaws.com/" + bucketName + "/ExampleObject.txt");
            }
        } catch (MalformedURLException e) {
            throw new RuntimeException("Unable to parse service endpoint: " + e.getMessage());
        }
        
        // construct the query parameter string to accompany the url
        Map<String, String> queryParams = new HashMap<String, String>();
         
        // for SignatureV4, the max expiry for a presigned url is 7 days,
        // expressed in seconds
        int expiresIn = 7 * 24 * 60 * 60;
        //有效日期
        queryParams.put("X-Amz-Expires", "" + expiresIn);
        //前端IP
        queryParams.put("x-amz-expect-ip", "" + expiresIn);
        //水印
        queryParams.put("X-Amz-WatermarkContent", "" + expiresIn);
        
        // we have no headers for this sample, but the signer will add 'host'
        Map<String, String> headers = new HashMap<String, String>();
        
        AWS4SignerForQueryParameterAuth signer = new AWS4SignerForQueryParameterAuth(
                endpointUrl, "GET", "s3", regionName);
        String authorizationQueryParameters = signer.computeSignature(headers, 
                                                       queryParams,
                                                       AWS4SignerBase.UNSIGNED_PAYLOAD,
                                                       awsAccessKey, 
                                                       awsSecretKey);
                
        // build the presigned url to incorporate the authorization elements as query parameters
        String presignedUrl = endpointUrl.toString() + "?" + authorizationQueryParameters;
        System.out.println("--------- Computed presigned url ---------");
        System.out.println(presignedUrl);
        System.out.println("------------------------------------------");
    }

    /**
     * 生成预签名
     * @param req
     * @return
     */
    public static String  generatePresignedUrl(GeneratePresignedUrlReq req) {

        //拼凑签名前缀
        URL endpointUrl = null;
        String domain=null;
        try {
            if (req.getRegionName().equals("us-east-1")) {
                domain=req.getBucketName() + ".s3." + req.getRegionName() + ".amazonaws.com";
                //endpointUrl = new URL("https://" + req.getBucketName() + ".s3." + req.getRegionName() + ".s3.amazonaws.com/"+req.getKey());
            }else {
                domain=req.getBucketName() + ".s3." + req.getRegionName() + ".amazonaws.com.cn";
                //endpointUrl = new URL("https://" + req.getBucketName() + ".s3." + req.getRegionName() + ".amazonaws.com.cn/"+req.getKey());
            }
            endpointUrl = new URL("https://" + domain+"/"+req.getKey());
        } catch (MalformedURLException e) {
            throw new RuntimeException("Unable to parse service endpoint: " + e.getMessage());
        }

        // construct the query parameter string to accompany the url
        Map<String, String> queryParams = new HashMap<String, String>();

        // for SignatureV4, the max expiry for a presigned url is 7 days,
        // expressed in seconds
        int expiresIn = 7 * 24 * 60 * 60;
        //有效日期
        queryParams.put("X-Amz-Expires", "" + req.getExpiresIn());
        //前端IP
        if(StringUtils.isNotEmpty(req.getExpectIp())) {
            //如果需要前端IP签名
            queryParams.put("x-amz-expect-ip", "" + req.getExpectIp());
        }
        //水印相关
        //水印内容 base64(eg:james,xx@xx.com,202306021047)
        queryParams.put("X-Amz-WatermarkContent", "" + req.getWatermarkContent());
        //水印颜色 eg:rgba(240,75,81,1)
        queryParams.put("X-Amz-WatermarkColor", "" + req.getWatermarkColor());
        //水印透明度 eg:1
        queryParams.put("X-Amz-WatermarkPreviewOpacity", "" + req.getWatermarkPreviewOpacity());
        //水印倾斜角 eg:8
        queryParams.put("X-Amz-WatermarkRotate", "" + req.getWatermarkRotate());

        queryParams.put("X-Amz-WatermarkDensity", "" + req.getWatermarkPreviewDensity());

        // we have no headers for this sample, but the signer will add 'host'
        Map<String, String> headers = new HashMap<String, String>();

        AWS4SignerForQueryParameterAuth signer = new AWS4SignerForQueryParameterAuth(
                endpointUrl, "GET", "s3", req.getRegionName());
        String authorizationQueryParameters = signer.computeSignature(headers,
                queryParams,
                AWS4SignerBase.UNSIGNED_PAYLOAD,
                req.getAwsAccessKey(),
                req.getAwsSecretKey());
        String presignedUrl = endpointUrl.toString() + "?" + authorizationQueryParameters;

        //如果有水印加速域名前缀
        if(StringUtils.isNotEmpty(S3Config.S3_WATER_MARK_SIGN_PREFIX)){
            presignedUrl=presignedUrl.replace(domain,S3Config.S3_WATER_MARK_SIGN_PREFIX);
        }


        return presignedUrl;
    }
}
