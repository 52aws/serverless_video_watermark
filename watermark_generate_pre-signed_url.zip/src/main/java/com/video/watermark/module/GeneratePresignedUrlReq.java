package com.video.watermark.module;

import lombok.Data;

/**
 * 生成签名url请求参数
 * @author fanjie
 * @date 2023-05-29
 */
@Data
public class GeneratePresignedUrlReq {
    /**
     * 桶名
     */
    private String bucketName;
    /**
     * 区域名
     */
    private String regionName;
    /**
     * 文件KEY
     */
    private String key;
    /**
     * 签名有效期
     */
    private Long expiresIn;
    /**
     * 前端IP，国内S3必须传递
     */
    private String expectIp;
    /**
     * 水印内容
     */
    private String watermarkContent;
    /**
     * 倾斜角
     */
    private Integer watermarkRotate;
    /**
     * 水印颜色
     */
    private String watermarkColor;
    /**
     * 水印颜色
     */
    private String watermarkPreviewOpacity;

    /**
     * aws AccessKey
     */
    private String awsAccessKey;
    /**
     * aws AccessKey
     */
    private String awsSecretKey;

    /**
     * 水印稠密度
     */
    private String watermarkPreviewDensity;
}
