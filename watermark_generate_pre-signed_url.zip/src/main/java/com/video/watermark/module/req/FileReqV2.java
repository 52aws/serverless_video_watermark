package com.video.watermark.module.req;

import lombok.Data;

@Data
public class FileReqV2 {


    private String fileId;
    private String signature ;
    private String fsAppId;

    private String scope;
    private long timestamp;
    //随机字符串
    private String nonceStr;

    private String ownerId;

    private String tsPath;

    private String tenant = "";
    /**
     * 水印内容
     */
    private GlobalWaterMarkReq waterMark;
    /**
     * 前端请求IP
     */
    private String frontReqIp ;


}
