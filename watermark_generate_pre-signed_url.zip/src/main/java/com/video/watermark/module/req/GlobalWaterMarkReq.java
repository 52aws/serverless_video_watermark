package com.video.watermark.module.req;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.util.List;

@Data
@Builder
@ToString
@AllArgsConstructor
@NoArgsConstructor
public class GlobalWaterMarkReq {
    @JsonProperty("watermark_list")
    private List<String> watermarkList;                   //水印分行内容
    private Integer rotate;                               //水印倾斜角度
    private String color;                                 //预览、下载文件水印颜色 RGBA格式 rgba(141,199,237,0.6)
    @JsonProperty("watermark_type_list")
    private List<DictionaryReq> watermarkTypeList;        //文件水印类型枚举
    @JsonProperty("watermark_content_list")
    private List<DictionaryReq> watermarkContentList;     //文件水印内容枚举
    @JsonProperty("watermark_color_list")
    private List<DictionaryReq> watermarkColorList;       //预览、下载文件可配置的水印颜色枚举列表
    @JsonProperty("print_color")
    private String printColor;                            //打印文件水印颜色 RGBA格式 rgba(141,199,237,0.6)
    @JsonProperty("watermark_print_color_list")
    private List<DictionaryReq> watermarkPrintColorList;  //打印文件水印可配置的颜色枚举列表
    @JsonProperty("watermark_preview_opacity")
    private String watermarkPreviewOpacity;               //文件预览、下载水印不透明度
    @JsonProperty("watermark_print_opacity")
    private String watermarkPrintOpacity;                 //文件打印水印不透明度

    @JsonProperty("watermark_preview_density")
    private String watermarkPreviewDensity;               //文件预览水印紧密度
    @JsonProperty("watermark_print_density")
    private String watermarkPrintDenstiy;                 //文件打印水印紧密度

}
