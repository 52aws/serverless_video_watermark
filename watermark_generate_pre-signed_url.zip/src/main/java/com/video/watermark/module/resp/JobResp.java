package com.video.watermark.module.resp;

import lombok.Data;

@Data
public class JobResp {
    private String jobId;
    private int status;
    private String errorMessage;
}
