package com.video.watermark.module.req;

import lombok.Builder;
import lombok.Data;
import lombok.ToString;

@Data
@Builder
@ToString
public class DictionaryReq {
    private Integer id;
    private String type;
    private String value;
}
