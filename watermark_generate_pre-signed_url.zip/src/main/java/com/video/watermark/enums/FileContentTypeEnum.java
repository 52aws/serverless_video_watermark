package com.video.watermark.enums;

/**
 */
public enum FileContentTypeEnum {
    UNKNOWN(0),
    VIDEO(1),
    AUDIO(2);
    // 文件类型：1，视频，2，音频

    private int type;

    FileContentTypeEnum(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "FileContentTypeEnum{" +
                "type=" + type +
                '}';
    }
}
