package com.video.watermark.enums;

/**
 */
public enum MediaConvertEnum {
    HLS(0);

    private int type;

    MediaConvertEnum(int type) {
        this.type = type;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    @Override
    public String toString() {
        return "MediaConvertEnum{" +
                "type=" + type +
                '}';
    }
}
