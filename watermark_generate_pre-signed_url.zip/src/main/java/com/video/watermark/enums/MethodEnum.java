package com.video.watermark.enums;

/**
 */
public enum MethodEnum {
    Post("POST"),
    Del("DELETE"),
    Put("PUT"),
    Get("GET");
    MethodEnum(String method) {
        this.method = method;
    }

    private String method;

    public String getMethod() {
        return method;
    }

    public void setMethod(String method) {
        this.method = method;
    }

    @Override
    public String toString() {
        return "MethodEnum{" +
                ", method='" + method + '\'' +
                '}';
    }
}
