package com.video.watermark.config;


import org.springframework.context.annotation.Configuration;

@Configuration
public class S3Config {
    //以下参数配置注入即可  todo
    public static String S3_ACCESS_KEY_ID;

    public static String S3_ACCESS_KEY_SECRET;

    public static long S3_MAX_SIZE;

    public static String BUCKET_NAME;

    public static String S3_DIR_PREFIX;

    public static int S3_EXPIRE;

    public static String S3_REGION;

    public static String S3_WATER_MARK_BUCKET_NAME;

    public static String S3_WATER_MARK_SIGN_PREFIX;

    public static String S3_WATER_MARK_SIGN_NG_IP;




}
