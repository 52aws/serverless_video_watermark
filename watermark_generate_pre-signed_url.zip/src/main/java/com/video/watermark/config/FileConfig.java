package com.video.watermark.config;
/**
 * @author fanyu
 */ //以下参数配置注入即可  todo
public class FileConfig {
    public static String host ;

    public static String uri ;

    public static String accessKey ;

    public static String secretKey ;

    public static String region ;

    public static String serviceName ;

    public static String role ;
}
