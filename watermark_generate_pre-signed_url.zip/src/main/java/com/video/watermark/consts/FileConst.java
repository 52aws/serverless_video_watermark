package com.video.watermark.consts;

public interface FileConst {

  String SLASH = "/";

  String VIDEO_HLS_PATH = "video_hls/";

  String AUDIO_HLS_PATH = "audio_hls/";

  String M3U8_SUFFIX = ".m3u8";

  String NAME_MODIFIER = "_nm";

  String VIDEO_STR = "video";

  String AUDIO_STR = "audio";
}
