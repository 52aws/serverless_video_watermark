package com.video.watermark.utils;


import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;

import com.video.watermark.config.FileConfig;
import com.video.watermark.consts.FileConst;
import com.video.watermark.enums.FileContentTypeEnum;
import com.video.watermark.enums.MethodEnum;
import com.video.watermark.module.resp.JobResp;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Configuration;
import org.springframework.stereotype.Component;

import java.security.MessageDigest;
import java.security.NoSuchAlgorithmException;
import java.security.SecureRandom;
import java.util.Map;
import java.util.TreeMap;


/**
 * @Description:
 */
@Configuration
@Component
@Slf4j
public class FileUtil {

    private static org.slf4j.Logger logger = LoggerFactory.getLogger(FileUtil.class);



    static ObjectMapper objectMapper = new ObjectMapper();

    public static String createToken() throws NoSuchAlgorithmException {
        SecureRandom prng = SecureRandom.getInstance("SHA1PRNG");
        String randomNum = Integer.valueOf(prng.nextInt()).toString();
        MessageDigest sha = MessageDigest.getInstance("SHA-1");
        byte[] result = sha.digest(randomNum.getBytes());
        return hexEncode(result);
    }


    public static String hexEncode(byte[] input) {
        StringBuilder result = new StringBuilder();
        char[] digits = {'0', '1', '2', '3', '4', '5', '6', '7', '8', '9', 'a',
                'b', 'c', 'd', 'e', 'f'};
        for (int idx = 0; idx < input.length; ++idx) {
            byte b = input[idx];
            result.append(digits[(b & 0xf0) >> 4]);
            result.append(digits[b & 0x0f]);
        }
        return result.toString();
    }




    public static String getFileIdByTsPath(String tsPath){
        if(StringUtils.isBlank(tsPath)){
            return "";
        }
        String[] args = tsPath.split(FileConst.SLASH);
        if(args.length > 3){
            return args[2].split("_")[0];
        }
        return "";
    }


    /**
     * api 调用MediaConvert
     * @param input
     * @param output
     * @return
     */
    public static String Convert(String input, String output, FileContentTypeEnum fcte, String definition){
        try {
            String json = "";
            if (fcte == FileContentTypeEnum.VIDEO) {
                json = getVideoConvertJsonV2(FileConfig.role, input, output, FileConst.NAME_MODIFIER,definition);
            } else if (fcte == FileContentTypeEnum.AUDIO) {
                json = getAudioOnlyConvertJson(FileConfig.role, input, output, FileConst.NAME_MODIFIER);
            }
            Map<String, String> headers = getHeaders(json, FileConfig.uri, MethodEnum.Post.getMethod());
            String result = "";
            for (int i = 0; i < 3; i++) {
                String res = HttpUtil.sendPost("https://" + FileConfig.host + FileConfig.uri, json, headers);
                if (StringUtils.isNotBlank(res)) {
                    result = res;
                    break;
                }
            }

            return result;
        }catch (Exception e){

            return "";
        }

    }

    /**
     * 通过API 获取job状态
     * @param jobId
     * @return
     */
    public static String getStatusByJobId(String jobId){
        Map<String,String> headers = getHeaders(null,FileConfig.uri+ FileConst.SLASH +jobId, MethodEnum.Get.getMethod());
        String res = HttpUtil.sendGet("https://"+FileConfig.host+FileConfig.uri+ FileConst.SLASH +jobId,headers);
        return res;
    }


    public static Map<String,String> getHeaders(String data,String uri,String httpMethod){
        TreeMap<String, String> awsHeaders = new TreeMap<String, String>();
        TreeMap<String, String> params = new TreeMap<String, String>();

        awsHeaders.put("host", FileConfig.host);
        return new AWSV4Auth.Builder(FileConfig.accessKey, FileConfig.secretKey)
                .regionName(FileConfig.region)
                .serviceName(FileConfig.serviceName)
                .httpMethodName(httpMethod)
                .canonicalURI(uri)
                .queryParametes(params)
                .awsHeaders(awsHeaders)
                .payload(data)
                //.debug()
                .build()
                .getHeaders();
    }

    /**
     * 处理Convert结果
     * @param result
     * @return
     */
    public static JobResp handleConvertResult(String result){

        //调用接口创建任务失败
        if(StringUtils.isBlank(result)){
            JobResp jr = new JobResp();
            jr.setJobId("");
            jr.setErrorMessage("mediaconvert api fail");
            jr.setStatus(0);
            return jr;
        }

        JsonNode jsonNode = null;
        try {
            jsonNode = objectMapper.readTree(result).get("job");
        } catch (JsonProcessingException e) {
            logger.error("error",e.getMessage(),e);
        }
        if(jsonNode == null){
            JobResp jr = new JobResp();
            jr.setJobId("");
            jr.setErrorMessage("mediaconvert api fail");
            jr.setStatus(0);
            return jr;
        }

        String jobId = jsonNode.get("id").asText();
        String status = jsonNode.get("status").asText();

        JobResp jr = new JobResp();
        jr.setJobId(jobId);
        jr.setErrorMessage("");

        if("SUBMITTED".equals(status)){
            jr.setStatus(1);
        }else if("PROGRESSING".equals(status)){
            jr.setStatus(2);
        }else if("COMPLETE".equals(status)){
            jr.setStatus(3);
        }else if("ERROR".equals(status)){
            jr.setStatus(4);
            String errorCode = jsonNode.get("errorCode").asText();
            String errorMessage = jsonNode.get("errorMessage").asText();

            if(StringUtils.isNotBlank(errorMessage) && errorMessage.length()>250){
                errorMessage = errorMessage.substring(0,250);
            }
            jr.setErrorMessage(errorMessage);
        }else{
            jr.setStatus(0);
        }

        return jr;
    }


    public static String getVideoConvertJsonV2(String role,String input , String output,String newName,String definition){
        String data = String.format("{\n" +
                "  \"UserMetadata\": {},\n" +
                "  \"Role\": \"%s\",\n" +
                "  \"Settings\": {\n" +
                "    \"OutputGroups\": [\n" +
                "      {\n" +
                "        \"Name\": \"Apple HLS\",\n" +
                "        \"Outputs\": [\n" +
                "          {\n" +
                "            \"ContainerSettings\": {\n" +
                "              \"Container\": \"M3U8\",\n" +
                "              \"M3u8Settings\": {\n" +
                "                \"AudioFramesPerPes\": 2,\n" +
                "                \"PcrControl\": \"PCR_EVERY_PES_PACKET\",\n" +
                "                \"PmtPid\": 480,\n" +
                "                \"PrivateMetadataPid\": 503,\n" +
                "                \"ProgramNumber\": 1,\n" +
                "                \"PatInterval\": 100,\n" +
                "                \"PmtInterval\": 100,\n" +
                "                \"VideoPid\": 481,\n" +
                "                \"AudioPids\": [\n" +
                "                  482,\n" +
                "                  483,\n" +
                "                  484,\n" +
                "                  485,\n" +
                "                  486,\n" +
                "                  487,\n" +
                "                  488,\n" +
                "                  489,\n" +
                "                  490,\n" +
                "                  491,\n" +
                "                  492\n" +
                "                ]\n" +
                "              }\n" +
                "            },\n" +
                "            \"VideoDescription\": {\n" +
/*                "              \"VideoPreprocessors\": {\n" +
                "                \"Deinterlacer\": {\n" +
                "                  \"Algorithm\": \"INTERPOLATE\",\n" +
                "                  \"Mode\": \"DEINTERLACE\"\n" +
                "                }\n" +
                "              },\n" +*/
                "              \"Width\": "+definition.split("x")[0]+",\n" +
                "              \"Height\": "+definition.split("x")[1]+",\n" +
                "              \"AntiAlias\": \"ENABLED\",\n" +
                "              \"Sharpness\": 100,\n" +
                "              \"CodecSettings\": {\n" +
                "                \"Codec\": \"H_264\",\n" +
                "                \"H264Settings\": {\n" +
                "                  \"InterlaceMode\": \"PROGRESSIVE\",\n" +
                "                  \"ParNumerator\": 1,\n" +
                "                  \"NumberReferenceFrames\": 3,\n" +
                "                  \"Softness\": 0,\n" +
                "                  \"FramerateDenominator\": 1001,\n" +
                "                  \"GopClosedCadence\": 1,\n" +
                "                  \"GopSize\": 90,\n" +
                "                  \"Slices\": 1,\n" +
                "                  \"HrdBufferSize\": 12500000,\n" +
                "                  \"ParDenominator\": 1,\n" +
                "                  \"SpatialAdaptiveQuantization\": \"ENABLED\",\n" +
                "                  \"TemporalAdaptiveQuantization\": \"DISABLED\",\n" +
                "                  \"FlickerAdaptiveQuantization\": \"DISABLED\",\n" +
                "                  \"EntropyEncoding\": \"CABAC\",\n" +
                "                  \"MaxBitrate\": 2000000,\n" +
                "                  \"FramerateControl\": \"SPECIFIED\",\n" +
                "                  \"RateControlMode\": \"QVBR\",\n" +
                "                  \"CodecProfile\": \"HIGH\",\n" +
                "                  \"QvbrSettings\": {\"QvbrQualityLevel\": 7},\n" +
                "                  \"Telecine\": \"NONE\",\n" +
                "                  \"FramerateNumerator\": 30000,\n" +
                "                  \"MinIInterval\": 0,\n" +
                "                  \"AdaptiveQuantization\": \"MEDIUM\",\n" +
                "                  \"CodecLevel\": \"LEVEL_4\",\n" +
                "                  \"SceneChangeDetect\": \"ENABLED\",\n" +
                "                  \"QualityTuningLevel\": \"SINGLE_PASS_HQ\",\n" +
                "                  \"GopSizeUnits\": \"FRAMES\",\n" +
                "                  \"ParControl\": \"SPECIFIED\",\n" +
                "                  \"NumberBFramesBetweenReferenceFrames\": 3,\n" +
                "                  \"HrdBufferInitialFillPercentage\": 90,\n" +
                "                  \"Syntax\": \"DEFAULT\"\n" +
                "                }\n" +
                "              },\n" +
                "              \"AfdSignaling\": \"NONE\",\n" +
                "              \"DropFrameTimecode\": \"ENABLED\",\n" +
                "              \"RespondToAfd\": \"NONE\",\n" +
                "              \"ColorMetadata\": \"INSERT\"\n" +
                "            },\n" +
                "            \"AudioDescriptions\": [\n" +
                "              {\n" +
                "                \"AudioTypeControl\": \"FOLLOW_INPUT\",\n" +
                "                \"AudioSourceName\": \"Audio Selector 1\",\n" +
                "                \"CodecSettings\": {\n" +
                "                  \"Codec\": \"AAC\",\n" +
                "                  \"AacSettings\": {\n" +
                "                    \"Bitrate\": 128000,\n" +
                "                    \"RateControlMode\": \"CBR\",\n" +
                "                    \"CodecProfile\": \"LC\",\n" +
                "                    \"CodingMode\": \"CODING_MODE_2_0\",\n" +
                "                    \"SampleRate\": 48000\n" +
                "                  }\n" +
                "                },\n" +
                "                \"LanguageCodeControl\": \"FOLLOW_INPUT\"\n" +
                "              }\n" +
                "            ],\n" +
                "            \"NameModifier\": \"%s\"\n" +
                "          }\n" +
                "        ],\n" +
                "        \"OutputGroupSettings\": {\n" +
                "          \"Type\": \"HLS_GROUP_SETTINGS\",\n" +
                "          \"HlsGroupSettings\": {\n" +
                "            \"ManifestDurationFormat\": \"INTEGER\",\n" +
                "            \"SegmentLength\": 15,\n" +
                "            \"TimedMetadataId3Period\": 10,\n" +
                "            \"CaptionLanguageSetting\": \"OMIT\",\n" +
                "            \"Destination\": \"%s\",\n" +
                "            \"TimedMetadataId3Frame\": \"PRIV\",\n" +
                "            \"CodecSpecification\": \"RFC_4281\",\n" +
                "            \"OutputSelection\": \"MANIFESTS_AND_SEGMENTS\",\n" +
                "            \"ProgramDateTimePeriod\": 600,\n" +
                "            \"MinSegmentLength\": 0,\n" +
                "            \"DirectoryStructure\": \"SINGLE_DIRECTORY\",\n" +
                "            \"ProgramDateTime\": \"EXCLUDE\",\n" +
                "            \"SegmentControl\": \"SEGMENTED_FILES\",\n" +
                "            \"ManifestCompression\": \"NONE\",\n" +
                "            \"ClientCache\": \"ENABLED\",\n" +
                "            \"StreamInfResolution\": \"INCLUDE\"\n" +
                "          }\n" +
                "        }\n" +
                "      }\n" +
                "    ],\n" +
                "    \"AdAvailOffset\": 0,\n" +
                "    \"Inputs\": [\n" +
                "      {\n" +
                "        \"AudioSelectors\": {\n" +
                "          \"Audio Selector 1\": {\n" +
                "            \"Tracks\": [\n" +
                "              1\n" +
                "            ],\n" +
                "            \"Offset\": 0,\n" +
                "            \"DefaultSelection\": \"DEFAULT\",\n" +
                "            \"SelectorType\": \"TRACK\",\n" +
                "            \"ProgramSelection\": 1\n" +
                "          }\n" +
                "        },\n" +
                "        \"VideoSelector\": {\n" +
                "          \"ColorSpace\": \"FOLLOW\"\n" +
                "        },\n" +
                "        \"FilterEnable\": \"AUTO\",\n" +
                "        \"PsiControl\": \"USE_PSI\",\n" +
                "        \"FilterStrength\": 0,\n" +
                "        \"DeblockFilter\": \"DISABLED\",\n" +
                "        \"DenoiseFilter\": \"DISABLED\",\n" +
                "        \"TimecodeSource\": \"EMBEDDED\",\n" +
                "        \"FileInput\": \"%s\"\n" +
                "      }\n" +
                "    ]\n" +
                "  }\n" +
                "}", role, newName,output, input);

        return data;
    }

    /**
     * 音频转换json
     * @param role
     * @param input
     * @param output
     * @param newName
     * @return
     */
    public static String getAudioOnlyConvertJson(String role,String input , String output,String newName){
        String data = String.format("{\n" +
                "  \"UserMetadata\": {},\n" +
                "  \"Role\": \"%s\",\n" +
                "  \"Settings\": {\n" +
                "    \"TimecodeConfig\": {\n" +
                "      \"Source\": \"ZEROBASED\"\n" +
                "    },\n" +
                "    \"OutputGroups\": [\n" +
                "      {\n" +
                "        \"CustomName\": \"hls-mp3\",\n" +
                "        \"Name\": \"Apple HLS\",\n" +
                "        \"Outputs\": [\n" +
                "          {\n" +
                "            \"ContainerSettings\": {\n" +
                "              \"Container\": \"M3U8\",\n" +
                "              \"M3u8Settings\": {}\n" +
                "            },\n" +
                "            \"AudioDescriptions\": [\n" +
                "              {\n" +
                "                \"AudioSourceName\": \"Audio Selector 1\",\n" +
                "                \"CodecSettings\": {\n" +
                "                  \"Codec\": \"AAC\",\n" +
                "                  \"AacSettings\": {\n" +
                "                    \"Bitrate\": 96000,\n" +
                "                    \"CodingMode\": \"CODING_MODE_2_0\",\n" +
                "                    \"SampleRate\": 48000\n" +
                "                  }\n" +
                "                }\n" +
                "              }\n" +
                "            ],\n" +
                "            \"OutputSettings\": {\n" +
                "              \"HlsSettings\": {}\n" +
                "            },\n" +
                "            \"NameModifier\": \"%s\"\n" +
                "          }\n" +
                "        ],\n" +
                "        \"OutputGroupSettings\": {\n" +
                "          \"Type\": \"HLS_GROUP_SETTINGS\",\n" +
                "          \"HlsGroupSettings\": {\n" +
                "            \"SegmentLength\": 10,\n" +
                "            \"Destination\": \"%s\",\n" +
                "            \"MinSegmentLength\": 0\n" +
                "          }\n" +
                "        }\n" +
                "      }\n" +
                "    ],\n" +
                "    \"Inputs\": [\n" +
                "      {\n" +
                "        \"AudioSelectors\": {\n" +
                "          \"Audio Selector 1\": {\n" +
                "            \"DefaultSelection\": \"DEFAULT\"\n" +
                "          }\n" +
                "        },\n" +
                "        \"VideoSelector\": {},\n" +
                "        \"TimecodeSource\": \"ZEROBASED\",\n" +
                "        \"FileInput\": \"%s\"\n" +
                "      }\n" +
                "    ]\n" +
                "  },\n" +
                "  \"AccelerationSettings\": {\n" +
                "    \"Mode\": \"DISABLED\"\n" +
                "  },\n" +
                "  \"StatusUpdateInterval\": \"SECONDS_60\",\n" +
                "  \"Priority\": 0\n" +
                "}", role,newName, output, input);

        return data;
    }

}
