package com.video.watermark.controller;

import com.amazonaws.services.s3.AmazonS3;
import com.video.watermark.aws.api.PresignedUrl;
import com.video.watermark.config.S3Config;
import com.video.watermark.consts.FileConst;
import com.video.watermark.module.GeneratePresignedUrlReq;
import com.video.watermark.module.req.FileReqV2;
import com.video.watermark.utils.FileUtil;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.FilenameUtils;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpServletRequest;
import java.net.URL;
import java.util.Date;

/**
 * @author fanjie
 */
@RestController
@RequestMapping("/file")
@Slf4j
public class VideoFileController {

    @Autowired(required = false)
    private AmazonS3 s3Client;

    /**
     * 获取ts文件下载链接
     * @param req
     * @return
     */
    @PostMapping("/download/ts")
    @ResponseBody
    public String downloadTs(@RequestBody FileReqV2 req,HttpServletRequest request) {

        String tsPath = req.getTsPath();
        String fileId = FileUtil.getFileIdByTsPath(tsPath);
        //通过fileId 读库对文件进行校验 不合法则直接返回错误信息 todo

        URL url = null;
        String strUrl=null;
        //获取扩展名
        String suffix = FilenameUtils.getExtension(tsPath);
        //只对分片信息进行动态水印处理
        if("ts".equals(suffix.toLowerCase())) {

            GeneratePresignedUrlReq urlParam=new GeneratePresignedUrlReq();
            urlParam.setAwsAccessKey(S3Config.S3_ACCESS_KEY_ID);
            urlParam.setAwsSecretKey(S3Config.S3_ACCESS_KEY_SECRET);
            urlParam.setBucketName(S3Config.S3_WATER_MARK_BUCKET_NAME);
            urlParam.setRegionName(S3Config.S3_REGION);
            // long expireTime = System.currentTimeMillis() + S3Config.S3_EXPIRE * 60 * 1000;
            //long expiresIn = 7 * 24 * 60 * 60;
            long expiresIn = 20 * 60;
            urlParam.setExpiresIn(expiresIn);
            String watermarkContent = StringUtils.join(req.getWaterMark().getWatermarkList(), ",");
            String watermarkColor = req.getWaterMark().getColor();


            urlParam.setWatermarkContent(watermarkContent);
            urlParam.setWatermarkColor(watermarkColor);
            urlParam.setWatermarkPreviewOpacity(req.getWaterMark().getWatermarkPreviewOpacity());
            urlParam.setWatermarkRotate(req.getWaterMark().getRotate());
            urlParam.setWatermarkPreviewDensity(req.getWaterMark().getWatermarkPreviewDensity());
            //urlParam.setExpectIp(req.getFrontReqIp());
            urlParam.setExpectIp(S3Config.S3_WATER_MARK_SIGN_NG_IP);
            urlParam.setKey(tsPath.replaceFirst(FileConst.SLASH,""));
            strUrl= PresignedUrl.generatePresignedUrl(urlParam);

        }else {//其他视频文件则正常签名即可

            long expireTime = System.currentTimeMillis() + S3Config.S3_EXPIRE * 60 * 1000;
            url = s3Client.generatePresignedUrl(S3Config.BUCKET_NAME, tsPath.replaceFirst(FileConst.SLASH, ""), new Date(expireTime));
            strUrl=url == null?"":url.toString();

        }

        return strUrl;
    }
}
